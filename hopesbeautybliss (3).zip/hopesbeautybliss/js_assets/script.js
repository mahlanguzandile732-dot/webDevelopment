console.log("Welcome to Hope's Beauty Bliss!");


window.addEventListener("DOMContentLoaded", function () {
    alert("Welcome to Hope's Beauty Bliss! We are happy to have you here.");

    
    const logo = document.querySelector(".responsive-image");

    if (logo) {
        logo.addEventListener("click", function () {
            alert("Thank you for visiting Hope's Beauty Bliss!");
        });
    }
});
// Welcome message
document.addEventListener("DOMContentLoaded", function () {

    const welcome = document.getElementById("welcomeMessage");

    if (welcome) {
        welcome.textContent =
            "We would love to hear from you! Contact Hope's Beauty Bliss today.";
    }

    // Show and hide opening hours
    const hoursButton = document.getElementById("hoursButton");
    const hoursMessage = document.getElementById("hoursMessage");

    if (hoursButton && hoursMessage) {
        hoursButton.addEventListener("click", function () {

            if (hoursMessage.style.display === "none") {
                hoursMessage.style.display = "block";
                hoursButton.textContent = "Hide Opening Hours";
            } else {
                hoursMessage.style.display = "none";
                hoursButton.textContent = "Show Opening Hours";
            }

        });
    }

    // Copy email address
    const copyButton = document.getElementById("copyEmail");

    if (copyButton) {
        copyButton.addEventListener("click", function () {

            navigator.clipboard.writeText(
                "hopesbeautybliss@gmail.com"
            ).then(function () {
                copyButton.textContent = "Email Copied!";
            }).catch(function () {
                alert("Please copy our email: hopesbeautybliss@gmail.com");
            });

        });
    }

});
// EmailJS configuration
const SERVICE_ID = "YOUR_SERVICE_ID";
const TEMPLATE_ID = "YOUR_TEMPLATE_ID";
const PUBLIC_KEY = "YOUR_PUBLIC_KEY";

// Initialise EmailJS
emailjs.init({
    publicKey: PUBLIC_KEY
});

// Contact form
const contactForm = document.getElementById("contactForm");

if (contactForm) {

    contactForm.addEventListener("submit", function(event) {

        event.preventDefault();

        const status = document.getElementById("contactStatus");

        if (!contactForm.checkValidity()) {
            contactForm.reportValidity();
            return;
        }

        status.textContent = "Sending your message...";

        emailjs.sendForm(
            SERVICE_ID,
            TEMPLATE_ID,
            contactForm
        )
        .then(function() {

            status.textContent =
                "Thank you! Your message has been sent successfully.";

            contactForm.reset();

        })
        .catch(function(error) {

            console.error("Email error:", error);

            status.textContent =
                "Sorry, your message could not be sent. Please try again.";

        });

    });
}
// ====================================
// ENQUIRY FORM VALIDATION
// ====================================

// Set today's date as the minimum date
const preferredDate = document.getElementById("preferredDate");

if (preferredDate) {
    const today = new Date();
    const localToday = new Date(
        today.getTime() - today.getTimezoneOffset() * 60000
    ).toISOString().split("T")[0];

    preferredDate.min = localToday;
}

// Select enquiry form
const enquiryForm = document.getElementById("enquiryForm");

if (enquiryForm) {

    enquiryForm.addEventListener("submit", function(event) {

        event.preventDefault();

        const status = document.getElementById("enquiryStatus");

        // Validate customer information
        if (!enquiryForm.checkValidity()) {
            enquiryForm.reportValidity();
            return;
        }

        // Check EmailJS is configured
        if (typeof emailjs === "undefined") {
            status.textContent =
                "Email service is unavailable. Please try again later.";
            return;
        }

        status.textContent = "Sending your enquiry...";

        // Send enquiry through EmailJS
        emailjs.sendForm(
            SERVICE_ID,
            ENQUIRY_TEMPLATE_ID,
            enquiryForm
        )

        .then(function() {

            status.textContent =
                "Thank you! Your enquiry has been sent successfully. We will get back to you.";

            enquiryForm.reset();

        })

        .catch(function(error) {

            console.error("Enquiry error:", error);

            status.textContent =
                "Unable to send your enquiry. Please try again.";

        });

    });

}
// ==========================================
// HOPE'S BEAUTY BLISS - DYNAMIC SERVICES
// ==========================================

const services = [
    {
        name: "Frontal Installation",
        category: "frontal",
        description: "Professional frontal installation to help you achieve a beautiful and neat look.",
        image: "_images/contact.jpeg"
    },
    {
        name: "Wig Installation",
        category: "wig",
        description: "Wig installation services designed to give you a beautiful and stylish appearance.",
        image: "_images/content.jpeg"
    },
    {
        name: "Hairstyling",
        category: "hair",
        description: "Beautiful hairstyling for different occasions and personal styles.",
        image: "_images/content2.jpeg"
    }
];

// Select HTML elements
const servicesContainer =
    document.getElementById("servicesContainer");

const serviceSearch =
    document.getElementById("serviceSearch");

const filterButtons =
    document.querySelectorAll(".filter-btn");

const noServices =
    document.getElementById("noServices");

// Display services dynamically
function displayServices(serviceList) {

    if (!servicesContainer) return;

    servicesContainer.innerHTML = "";

    serviceList.forEach(function(service) {

        const card = document.createElement("div");

        card.classList.add("service-card");

        const image = document.createElement("img");
        image.src = service.image;
        image.alt = service.name;
        image.loading = "lazy";

        const title = document.createElement("h3");
        title.textContent = service.name;

        const description = document.createElement("p");
        description.textContent = service.description;

        const enquiryLink = document.createElement("a");
        enquiryLink.href = "enquiries.html";
        enquiryLink.classList.add("enquiry-link");
        enquiryLink.textContent = "Enquire About Price";

        card.appendChild(image);
        card.appendChild(title);
        card.appendChild(description);
        card.appendChild(enquiryLink);

        servicesContainer.appendChild(card);

    });

    if (noServices) {
        noServices.hidden = serviceList.length !== 0;
    }
}

// Display all services when the page loads
displayServices(services);


// ==========================================
// SERVICE SEARCH FUNCTIONALITY
// ==========================================

let selectedCategory = "all";

function filterServices() {

    if (!serviceSearch) return;

    const searchText =
        serviceSearch.value.toLowerCase().trim();

    const filteredServices = services.filter(function(service) {

        const matchesSearch =
            service.name.toLowerCase().includes(searchText) ||
            service.description.toLowerCase().includes(searchText);

        const matchesCategory =
            selectedCategory === "all" ||
            service.category === selectedCategory;

        return matchesSearch && matchesCategory;

    });

    displayServices(filteredServices);
}

// Search as the customer types
if (serviceSearch) {
    serviceSearch.addEventListener("input", filterServices);
}


// ==========================================
// SERVICE CATEGORY FILTER
// ==========================================

filterButtons.forEach(function(button) {

    button.addEventListener("click", function() {

        filterButtons.forEach(function(btn) {
            btn.classList.remove("active");
        });

        button.classList.add("active");

        selectedCategory = button.dataset.filter;

        filterServices();

    });

});


// ==========================================
// IMAGE GALLERY LIGHTBOX
// ==========================================

const galleryImages =
    document.querySelectorAll(".gallery-image");

const lightbox =
    document.getElementById("lightbox");

const lightboxImage =
    document.getElementById("lightboxImage");

const closeLightbox =
    document.getElementById("closeLightbox");

function openLightbox(image) {

    if (!lightbox || !lightboxImage) return;

    lightboxImage.src = image.src;
    lightboxImage.alt = image.alt;

    lightbox.hidden = false;

    if (closeLightbox) {
        closeLightbox.focus();
    }

}

function hideLightbox() {

    if (!lightbox) return;

    lightbox.hidden = true;
    lightboxImage.src = "";

}

galleryImages.forEach(function(image) {

    image.addEventListener("click", function() {
        openLightbox(image);
    });

});

if (closeLightbox) {
    closeLightbox.addEventListener("click", hideLightbox);
}

// Close lightbox when clicking outside the image
if (lightbox) {

    lightbox.addEventListener("click", function(event) {

        if (event.target === lightbox) {
            hideLightbox();
        }

    });

}

// Close lightbox using Escape key
document.addEventListener("keydown", function(event) {

    if (event.key === "Escape") {
        hideLightbox();
    }

});